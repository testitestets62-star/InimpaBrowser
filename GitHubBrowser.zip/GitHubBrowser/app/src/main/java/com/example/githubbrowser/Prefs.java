package com.example.githubbrowser;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    // type: b = Schalter, t = Text
    public static final String[][] ALL = {
        {"b", "js", "JavaScript aktivieren", "true"},
        {"b", "dom", "DOM-Speicher (localStorage)", "true"},
        {"b", "zoom", "Zoom per Fingergeste", "true"},
        {"b", "desktop", "Desktop-Modus", "false"},
        {"b", "images", "Bilder laden", "true"},
        {"b", "cookies", "Cookies erlauben", "true"},
        {"b", "thirdcookies", "Drittanbieter-Cookies erlauben", "false"},
        {"b", "geo", "Standortfreigabe erlauben", "false"},
        {"b", "autoplay", "Autoplay blockieren", "true"},
        {"b", "mixed", "Gemischte Inhalte (HTTP in HTTPS) erlauben", "false"},
        {"b", "fileaccess", "Dateizugriff erlauben", "false"},
        {"b", "contentaccess", "Content-Provider-Zugriff erlauben", "false"},
        {"b", "safe", "Safe Browsing", "true"},
        {"b", "dark", "Erzwungener Dunkelmodus", "false"},
        {"b", "keepon", "Bildschirm anlassen", "false"},
        {"b", "fullscreen", "Vollbild (Statusleiste ausblenden)", "false"},
        {"b", "adblock", "Einfacher Werbe-/Tracker-Blocker", "true"},
        {"b", "cache", "Cache verwenden", "true"},
        {"b", "overview", "Seite an Bildschirm anpassen", "true"},
        {"b", "popups", "Popups/neue Fenster per JS erlauben", "false"},
        {"b", "externalLinks", "Fremde Links extern \u00f6ffnen", "true"},
        {"b", "debug", "WebView-Debugging (chrome://inspect)", "false"},
        {"t", "textzoom", "Textgr\u00f6\u00dfe in % (z.B. 100)", "100"},
        {"t", "home", "Startseite", "https://github.com"},
        {"t", "search", "Suchmaschine (%s = Suchbegriff)", "https://duckduckgo.com/?q=%s"},
        {"t", "ua", "Eigener User-Agent (leer = Standard)", ""},
    };
    public static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }
    public static boolean b(Context c, String k) {
        for (String[] s : ALL) if (s[1].equals(k)) return sp(c).getBoolean(k, Boolean.parseBoolean(s[3]));
        return false;
    }
    public static String t(Context c, String k) {
        for (String[] s : ALL) if (s[1].equals(k)) return sp(c).getString(k, s[3]);
        return "";
    }
}
